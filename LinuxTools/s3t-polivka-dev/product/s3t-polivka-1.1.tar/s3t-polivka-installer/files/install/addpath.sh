#!/bin/bash

echo -e "PATH=\"\$PATH:/usr/s3t-polivka/${1}\"" >> /etc/profile.d/s3t-polivka_setpath.sh
