#!/bin/bash
PATH="$PATH:/usr/s3t-polivka/bin"
